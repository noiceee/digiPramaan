require("dotenv").config();
const { GANACHE_HOST, GANACHE_PORT, INFURA_API, MNEMONIC } = process.env;

const HDWalletProvider = require("truffle-hdwallet-provider");

module.exports = {
  networks: {
    development: {
      host: "127.0.0.1", // Localhost (default: none)
      port: 7545, // Standard Ethereum port (default: none)
      network_id: "*", // Any network (default: none)
    },
    ganacheNetwork: {
      host: GANACHE_HOST,
      port: GANACHE_PORT,
      network_id: "*",
    },
    rinkeby: {
      provider: function () {
        return new HDWalletProvider(
          MNEMONIC,
          `https://sepolia.infura.io/v3/${INFURA_API}`
        );
      },
      network_id: 11155111,
      gas: 5500000,
      gasPrice: 30000000000,
      networkCheckTimeout: 10000,
    },
  },
  mocha: {
    // timeout: 100000
  },

  compilers: {
    solc: {
      version: "0.8.19",
    },
  },
};
